package medicamento.Medicamentos;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
@RestController
@RequestMapping("/medicacao")
public class Medicamento {

    @Size(min = 3, max = 5)
    @NotBlank
    private String codigo;
    @Size(min = 4, max = 30)
    @NotBlank
    private String nome;
    @PositiveOrZero()
    private Double valorUnd;
    @PositiveOrZero()
    private Integer quantidade;
    private boolean precisaReceita;

    private List<Medicamento> listaMedicamentos = new ArrayList<>();

    @GetMapping
    public ResponseEntity<List<Medicamento>> listarMedicamento(){
        if (!listaMedicamentos.isEmpty()){
            return ResponseEntity.status(200).body(listaMedicamentos);
        }
        return ResponseEntity.status(204).build();
    }

    @PostMapping
    public ResponseEntity <List<Medicamento>> adicionarMedicamento(@RequestBody  @Valid  Medicamento medicamentoNovo){

        listaMedicamentos.add(medicamentoNovo);
        return ResponseEntity.status(201).body(listaMedicamentos);

    }

    public void atualizarMedicamento (MedicamentoAtualizado medicamentoAtualizado){

        setQuantidade(medicamentoAtualizado.getNovaQuantidade());
        setValorUnd(medicamentoAtualizado.getNovoValorUnd());
    }

    @PatchMapping("/{indice}")
    public ResponseEntity<List<Medicamento>> atualizarMedicamento(@PathVariable int indice,
                                                                  @RequestBody @Valid MedicamentoAtualizado medicamentoAtualizado){
        if (indice < 0 || indice >= listaMedicamentos.size()) {
            return ResponseEntity.status(404).build();
        }

        Medicamento medicamento = listaMedicamentos.get(indice);
        medicamento.atualizarMedicamento(medicamentoAtualizado);

        return ResponseEntity.status(200).body(listaMedicamentos);

    }


    @DeleteMapping("/{indice}")
    public ResponseEntity<Medicamento>deletarMedicamento(@PathVariable int indice){
        if (indice < 0 || indice > listaMedicamentos.size()) {
         return ResponseEntity.status(404).build();
        }

        listaMedicamentos.remove(indice);
        return ResponseEntity.status(204).build();
    }

    @GetMapping("/{controlados}")
    public  ResponseEntity<List<Medicamento>> getControlados(){

        return ResponseEntity.status(200).body(listaMedicamentos.stream().filter(controlado -> controlado.precisaReceita).toList());
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public Double getValorUnd() {
        return valorUnd;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public Boolean getPrecisaReceita() {
        return precisaReceita;
    }

    public void setValorUnd(Double valorUnd) {
        this.valorUnd = valorUnd;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }
}
