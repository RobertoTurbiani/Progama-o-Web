package medicamento.Medicamentos;


import jakarta.validation.constraints.PositiveOrZero;

public class MedicamentoAtualizado {
    @PositiveOrZero
    private double novoValorUnd;

    @PositiveOrZero
    private int novaQuantidade;

    public double getNovoValorUnd() {
        return novoValorUnd;
    }
    public int getNovaQuantidade() {
        return novaQuantidade;
    }

}