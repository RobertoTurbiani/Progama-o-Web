package ExheroisTreino.herois;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeroisApplicationTests {

	@Test
	void contextLoads() {
	}

}
