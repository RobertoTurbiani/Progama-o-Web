package ExheroisTreino.herois;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HeroisApplication {

	public static void main(String[] args) {
		SpringApplication.run(HeroisApplication.class, args);
	}

}
