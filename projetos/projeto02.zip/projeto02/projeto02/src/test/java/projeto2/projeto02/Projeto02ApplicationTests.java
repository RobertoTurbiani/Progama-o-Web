package projeto2.projeto02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
