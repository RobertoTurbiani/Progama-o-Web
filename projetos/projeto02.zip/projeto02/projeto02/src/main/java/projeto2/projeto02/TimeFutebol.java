package projeto2.projeto02;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.concurrent.ThreadLocalRandom;

public class TimeFutebol {

    private String nome;
    private int vitorias;
    private int empates;
    private int derrotas;
    @JsonIgnore
    private Double patrimonio = ThreadLocalRandom.current()
            .nextDouble(100,100_000);

    public TimeFutebol(String nome, int vitorias, int empates, int derrotas) {
        this.nome = nome;
        this.vitorias = vitorias;
        this.empates = empates;
        this.derrotas = derrotas;
    }

    public String getNome() {
        return nome;
    }

    public int getVitorias() {
        return vitorias;
    }

    public int getEmpates() {
        return empates;
    }

    public int getDerrotas() {
        return derrotas;
    }

    public int getPontos(){

        return vitorias*3 + empates;
    }
    public Double getPatrimonio() {
        return patrimonio;
    }
}
