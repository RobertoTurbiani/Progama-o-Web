package projeto2.projeto02;

public class Heroi {

    private String nome;
    private String descricao;
    private Integer forca;
    private String classe;

    public Heroi(String nome, String descricao, Integer forca) {
        this.nome = nome;
        this.descricao = descricao;
        this.forca = forca;
        this.classe = classe;
    }

    public Integer getForca() {
        return forca ;
    }

    public String getClasse() {

        if (forca <= 500){
          return ("C");
        } else if (forca < 8000) {
            return ("B");
        } else if (forca < 20000) {
            return ("A");
        } else {
            return ("S");
        }
    }

    public String getNome() {
        return nome;
    }

    public String getDescricao() {
        return descricao;
    }
}
