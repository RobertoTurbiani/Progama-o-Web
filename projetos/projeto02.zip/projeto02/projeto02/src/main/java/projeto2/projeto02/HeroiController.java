package projeto2.projeto02;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/herois")
public class HeroiController {

    private List<Heroi> listaherois = new ArrayList<>();
    @GetMapping("/herois")
    public List <Heroi> herois(){
        return listaherois;
    };
    @GetMapping("/herois/{nome}/{descricao}/{forca}")
    public List<Heroi> infoHero(@PathVariable String nome, @PathVariable String descricao, @PathVariable Integer forca) {
        Heroi novoHeroi = new Heroi(nome,descricao,forca) ;
        listaherois.add(novoHeroi);
        return listaherois;
    }

    @GetMapping("/herois/classe/{classe}")
    public List<Heroi> classeHeroi (@PathVariable String classe) {

        return listaherois.stream().filter(heroi -> heroi.getClasse().contains(classe)).toList();
    }
}