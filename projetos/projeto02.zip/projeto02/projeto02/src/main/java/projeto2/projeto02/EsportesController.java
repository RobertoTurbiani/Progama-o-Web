package projeto2.projeto02;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/esportes")
public class EsportesController {

    private List<String> esportes = new ArrayList<>(List.of("Futebol","Basquete","Xadrez","Esgrima","MMA"));

    @GetMapping("/consulta")
    public  List<String> consultar(@RequestParam String pesquisa){

        return  esportes.stream().filter(esporte -> esporte.contains(pesquisa)).toList();
    };

    @GetMapping("/consulta-complexa")
    public List<String> consultarComplexo( @RequestParam String pesquisa,
                                           @RequestParam Integer tamanho){

        return esportes.stream().filter(esporte -> esporte.contains(pesquisa) && esporte.length()>= tamanho).toList();
        }
}
