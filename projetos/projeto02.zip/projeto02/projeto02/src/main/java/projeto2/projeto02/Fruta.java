package projeto2.projeto02;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/frutas")
public class Fruta {

    private List<String> frutas = new ArrayList<>(List.of("Banana","Uva","Tomate"));
    @GetMapping("/nova/{nomeFrutas}")
    public String cadastro(@PathVariable String nomeFrutas){
        frutas.add(nomeFrutas);
        return "Fruta adicionada %s ".formatted(nomeFrutas);
    }

    @GetMapping("/contagem")
    public Integer contagem(){
        return frutas.size();
    }

    @GetMapping("/consulta/{nomeFruta}")
    public void consulta(@PathVariable String nomeFruta){

        if (nomeFruta.equals(frutas)){
            System.out.println("Fruta encontrada");
        } else {
            System.out.println("fruta não encontrada");
        }
    }
}